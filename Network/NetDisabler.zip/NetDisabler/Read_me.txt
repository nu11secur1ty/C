Author: BlueLife , Velociraptor
www.sordum.org

[###################]--Net Disabler v1.1--[###################]

(Thursday, April 8, 2021)
------------
Changelog:

1.[ADDED] - Language Support
2.[ADDED] - Block with Proxy feature
3.[ADDED] - Enable or Disable Internet via System Tray Icon
4.[ADDED] - Enable / Disable Internet Buttons
5.[ADDED] - Checkbox icons
6.[ADDED] - Open Internet, Hide window on startup and hide when minimized options (Under the Menu)
7.[FIXED] - GUI letters are too small
8.[FIXED] - It is difficult to remove each box individually when we want to unblock Internet (In this version You can remove the internet ban without removing the ticks in the boxes)
9. [ADDED] - Some code improvements

[###################]--Net Disabler v1.0--[###################]

(Tuesday, 21 February 2017)
------------
First release, A small portable Freeware tool "NetDisabler" can help you to quickly turn the Internet off or on